"""R0/R1 eval harness: scores any diagnoser against eval/gold/*.json.

Deterministic proxy metrics need zero LLM calls, so this is also the regression gate in CI.
Features: frozen dev/test split, tagged result files, incremental saving (+ --resume), per-incident
traces, token/call accounting, crash reporting, and an audit log of every test-set opening.
Adapter contract: a diagnoser is a callable ``incident_id -> DiagnosisResult``.
"""

from __future__ import annotations

import argparse
import json
import re
from collections.abc import Callable
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[3]
GOLD_DIR = ROOT / "eval" / "gold"
RESULTS_DIR = ROOT / "eval" / "results"
TRACE_DIR = ROOT / "eval" / "traces"
SPLITS_FILE = ROOT / "eval" / "splits.json"
OPENINGS_LOG = ROOT / "eval" / "test_openings.log"

_STOP = {
    "the",
    "and",
    "for",
    "with",
    "that",
    "this",
    "from",
    "are",
    "was",
    "into",
    "per",
    "its",
    "has",
    "have",
    "then",
    "than",
    "not",
    "but",
    "all",
    "any",
    "can",
    "will",
    "starting",
}
_FALSE_ALARM_MARKERS = ("false alarm", "no incident", "no real incident", "not an incident")
_TAG = re.compile(r"^[A-Za-z0-9_.-]+$")


@dataclass
class DiagnosisResult:
    """Framework-neutral diagnosis, so any agent version can be scored."""

    incident_id: str
    root_cause: str
    evidence: list[str] = field(default_factory=list)
    risk_tier: str = "unknown"
    steps: int = 0
    error: str = ""  # set by an adapter that caught a crash but still has a partial trace
    trace: dict[str, Any] = field(default_factory=dict)
    usage: dict[str, int] = field(default_factory=dict)
    degraded: str = ""  # non-empty when the agent returned a flagged fallback instead of a real diagnosis


@dataclass
class IncidentScore:
    incident_id: str
    category: str
    difficulty: str
    root_cause_f1: float
    evidence_recall: float
    risk_match: bool
    false_alarm_ok: bool
    answered: bool  # produced any root cause other than "Unknown"
    error: str = ""  # non-empty when the agent crashed on this incident
    usage: dict[str, int] = field(default_factory=dict)
    degraded: str = ""
    gold_false_alarm: bool = False
    claimed_false_alarm: bool = False
    debate_verdict: str = ""  # Stage 8 runs only: confirmed / revised / revision_rejected / no_challenges / ...


def _tokens(text: str) -> set[str]:
    return {t for t in re.findall(r"[a-z0-9_]{3,}", text.lower()) if t not in _STOP}


def f1_overlap(pred: str, ref: str) -> float:
    p, r = _tokens(pred), _tokens(ref)
    if not p or not r:
        return 0.0
    common = len(p & r)
    if common == 0:
        return 0.0
    prec, rec = common / len(p), common / len(r)
    return 2 * prec * rec / (prec + rec)


def evidence_recall(pred: list[str], gold: list[str]) -> float:
    """Share of gold evidence items whose key tokens appear in the predicted evidence."""
    if not gold:
        return 1.0
    pred_tokens = _tokens(" ".join(pred))
    hit = 0
    for g in gold:
        gt = _tokens(g)
        if gt and len(gt & pred_tokens) / len(gt) >= 0.5:
            hit += 1
    return hit / len(gold)


def score_one(gold: dict, result: DiagnosisResult, error: str = "") -> IncidentScore:
    claims_false_alarm = any(m in result.root_cause.lower() for m in _FALSE_ALARM_MARKERS)
    is_fa = bool(gold.get("is_false_alarm"))
    return IncidentScore(
        incident_id=gold["incident_id"],
        category=gold["category"],
        difficulty=gold["difficulty"],
        root_cause_f1=round(f1_overlap(result.root_cause, gold["root_cause"]), 3),
        evidence_recall=round(evidence_recall(result.evidence, gold["evidence"]), 3),
        risk_match=result.risk_tier == gold["remediation_risk_tier"],
        false_alarm_ok=claims_false_alarm == is_fa,
        answered=not result.root_cause.lower().startswith("unknown"),
        error=error or result.error,
        usage=result.usage,
        degraded=result.degraded,
        gold_false_alarm=is_fa,
        claimed_false_alarm=claims_false_alarm,
        debate_verdict=str(result.trace.get("debate", {}).get("verdict", "")),
    )


def _rate(hits: int, total: int) -> float | None:
    return round(hits / total, 3) if total else None


def summarize(scores: list[IncidentScore]) -> dict[str, Any]:
    n = len(scores) or 1
    gold_fa = [s for s in scores if s.gold_false_alarm]
    gold_real = [s for s in scores if not s.gold_false_alarm]
    return {
        "n": len(scores),
        "root_cause_f1": round(sum(s.root_cause_f1 for s in scores) / n, 3),
        "evidence_recall": round(sum(s.evidence_recall for s in scores) / n, 3),
        "risk_accuracy": round(sum(s.risk_match for s in scores) / n, 3),
        "false_alarm_accuracy": round(sum(s.false_alarm_ok for s in scores) / n, 3),
        "answered_rate": round(sum(s.answered for s in scores) / n, 3),
        # Stage 8: false positive = a real-incident claim on a gold false alarm; false negative = a false-alarm
        # claim on a real incident. None when the run has no incident of that kind (rate undefined).
        "false_positive_rate": _rate(sum(not s.claimed_false_alarm for s in gold_fa), len(gold_fa)),
        "false_negative_rate": _rate(sum(s.claimed_false_alarm for s in gold_real), len(gold_real)),
        "gold_false_alarms": len(gold_fa),
        "debate_revised": sum(s.debate_verdict == "revised" for s in scores),
        "debate_rejected": sum(s.debate_verdict == "revision_rejected" for s in scores),
        "crashed": sum(bool(s.error) for s in scores),
        "degraded": sum(bool(s.degraded) for s in scores),
        "llm_calls": sum(s.usage.get("calls", 0) for s in scores),
        "prompt_tokens": sum(s.usage.get("prompt_tokens", 0) for s in scores),
        "completion_tokens": sum(s.usage.get("completion_tokens", 0) for s in scores),
    }


def load_split(name: str, splits_file: Path | None = None) -> list[str]:
    data = json.loads((splits_file or SPLITS_FILE).read_text())
    if name not in ("dev", "test"):
        raise ValueError(f"unknown split {name!r} (use dev, test or all)")
    return list(data[name])


def evaluate(
    diagnose: Callable[[str], DiagnosisResult],
    gold_dir: Path | None = None,
    limit: int | None = None,
    ids: list[str] | None = None,
    on_result: Callable[[IncidentScore, DiagnosisResult], None] | None = None,
    skip: dict[str, IncidentScore] | None = None,
) -> dict:
    """Run `diagnose` over gold incidents. `skip` holds already-finished scores (for --resume)."""
    paths = sorted((gold_dir or GOLD_DIR).glob("INC-*.json"))
    if ids:
        known = {p.stem for p in paths}
        unknown = sorted(set(ids) - known)
        if unknown:
            raise ValueError(f"unknown incident ids: {', '.join(unknown)}")
        paths = [p for p in paths if p.stem in set(ids)]
    paths = paths[:limit]
    scores: list[IncidentScore] = []
    for path in paths:
        gold = json.loads(path.read_text())
        iid = gold["incident_id"]
        if skip and iid in skip:
            scores.append(skip[iid])
            continue
        error = ""
        try:
            res = diagnose(iid)
        except Exception as exc:  # a crash is a failed incident, not a skipped one
            error = f"{type(exc).__name__}: {exc}"
            res = DiagnosisResult(iid, f"Unknown (error: {exc})")
        score = score_one(gold, res, error)
        scores.append(score)
        if on_result:
            on_result(score, res)
    return {"summary": summarize(scores), "incidents": [asdict(s) for s in scores]}


def react_baseline(incident_id: str) -> DiagnosisResult:
    """Adapter for the legacy rule-based ReActAgent (Stage 3)."""
    from incident_agent.agents.react_agent import ReActAgent

    agent = ReActAgent()
    obs = agent.observe(incident_id)
    d = agent.act(obs, agent.reason(obs))
    return DiagnosisResult(
        incident_id=incident_id,
        root_cause=d.root_cause,
        evidence=[e.detail for e in d.evidence],
        risk_tier=getattr(d.risk_tier, "value", str(d.risk_tier)),
        steps=len(d.reasoning_steps),
    )


def make_llm_react(temperature: float = 0.0, risk_guard: bool = False) -> Callable[[str], DiagnosisResult]:
    """Adapter factory for the LLM ReAct agent (needs GROQ_API_KEY; responses are disk-cached)."""
    from incident_agent.agents.llm_react_agent import LLMReActAgent
    from incident_agent.llm import TrackingClient, build_client

    shared = build_client()  # shared so cache/fallback state spans the whole run

    def run(incident_id: str) -> DiagnosisResult:
        client = TrackingClient(shared)
        agent = LLMReActAgent(client, temperature=temperature, risk_guard=risk_guard)
        trace: dict[str, Any] = {}
        try:
            d = agent.run(incident_id)
        except Exception as exc:  # keep the partial trace: it is the best debugging evidence
            trace = _agent_trace(agent)
            return DiagnosisResult(
                incident_id,
                f"Unknown (error: {exc})",
                error=f"{type(exc).__name__}: {exc}",
                trace=trace,
                usage=client.summary(),
            )
        trace = _agent_trace(agent)
        trace["diagnosis"] = d.model_dump(mode="json")
        return DiagnosisResult(
            incident_id=incident_id,
            root_cause=d.root_cause,
            evidence=[e.detail for e in d.evidence],
            risk_tier=d.risk_tier.value,
            steps=len(d.reasoning_steps),
            trace=trace,
            usage=client.summary(),
            degraded=agent.degraded or "",
        )

    return run


def make_llm_orchestrator(
    temperature: float = 0.0, parallel: bool = True, risk_guard: bool = False
) -> Callable[[str], DiagnosisResult]:
    """Adapter factory for the LLM orchestrator-workers system (same scoring, same accounting)."""
    from incident_agent.agents.llm_orchestrator import LLMOrchestrator
    from incident_agent.llm import TrackingClient, build_client

    shared = build_client()

    def run(incident_id: str) -> DiagnosisResult:
        client = TrackingClient(shared)
        agent = LLMOrchestrator(client, temperature=temperature, parallel=parallel, risk_guard=risk_guard)
        try:
            d = agent.run(incident_id)
        except Exception as exc:
            return DiagnosisResult(
                incident_id,
                f"Unknown (error: {exc})",
                error=f"{type(exc).__name__}: {exc}",
                trace=_agent_trace(agent),
                usage=client.summary(),
            )
        trace = _agent_trace(agent)
        trace["diagnosis"] = d.model_dump(mode="json")
        return DiagnosisResult(
            incident_id=incident_id,
            root_cause=d.root_cause,
            evidence=[e.detail for e in d.evidence],
            risk_tier=d.risk_tier.value,
            steps=len(d.reasoning_steps),
            trace=trace,
            usage=client.summary(),
            degraded=agent.degraded or "",
        )

    return run


def make_llm_swarm(
    temperature: float = 0.0, allow_revision: bool = True, risk_guard: bool = False, debate: bool = False
) -> Callable[[str], DiagnosisResult]:
    """Adapter factory for the hierarchical swarm (commander over orchestrator over workers)."""
    from incident_agent.agents.swarm import HierarchicalSwarm
    from incident_agent.llm import TrackingClient, build_client

    shared = build_client()

    def run(incident_id: str) -> DiagnosisResult:
        client = TrackingClient(shared)
        agent = HierarchicalSwarm(
            client, temperature=temperature, allow_revision=allow_revision, risk_guard=risk_guard, debate=debate
        )
        try:
            out = agent.run(incident_id)
        except Exception as exc:
            return DiagnosisResult(
                incident_id,
                f"Unknown (error: {exc})",
                error=f"{type(exc).__name__}: {exc}",
                trace=_agent_trace(agent),
                usage=client.summary(),
            )
        d = out.diagnosis
        trace = _agent_trace(agent)
        trace["diagnosis"] = d.model_dump(mode="json")
        if agent.debate_record is not None:
            trace["debate"] = agent.debate_record.to_dict()
            trace["debate"]["original_root_cause"] = agent.debate_record.original.root_cause
        trace["commander"] = {
            "escalation": out.escalation_decision,
            "escalation_reason": agent.result.escalation_reason if agent.result else "",
            "severity": out.severity_assessment,
            "narrative": out.narrative,
            "revision_applied": bool(agent.result and agent.result.revision_applied),
            "fallback": agent.result.fallback_reason if agent.result else "",
            "confidence": out.confidence,
        }
        return DiagnosisResult(
            incident_id=incident_id,
            root_cause=d.root_cause,
            evidence=[e.detail for e in d.evidence],
            risk_tier=d.risk_tier.value,
            steps=len(d.reasoning_steps),
            trace=trace,
            usage=client.summary(),
            degraded=agent.degraded or "",
        )

    return run


def make_llm_debate(
    temperature: float = 0.0, parallel: bool = True, risk_guard: bool = False
) -> Callable[[str], DiagnosisResult]:
    """Stage 8 adapter: orchestrator, then defender-vs-examiner debate. Re-uses cached orchestrator calls."""
    from incident_agent.agents.llm_debate import DebatedOrchestrator
    from incident_agent.llm import TrackingClient, build_client

    shared = build_client()

    def run(incident_id: str) -> DiagnosisResult:
        client = TrackingClient(shared)
        agent = DebatedOrchestrator(client, temperature=temperature, risk_guard=risk_guard, parallel=parallel)
        try:
            d = agent.run(incident_id)
        except Exception as exc:
            return DiagnosisResult(
                incident_id,
                f"Unknown (error: {exc})",
                error=f"{type(exc).__name__}: {exc}",
                trace=_agent_trace(agent),
                usage=client.summary(),
            )
        trace = _agent_trace(agent)
        trace["diagnosis"] = d.model_dump(mode="json")
        if agent.record is not None:
            trace["debate"] = agent.record.to_dict()
            trace["debate"]["original_root_cause"] = agent.record.original.root_cause
        return DiagnosisResult(
            incident_id=incident_id,
            root_cause=d.root_cause,
            evidence=[e.detail for e in d.evidence],
            risk_tier=d.risk_tier.value,
            steps=len(d.reasoning_steps),
            trace=trace,
            usage=client.summary(),
            degraded=agent.degraded or "",
        )

    return run


def _agent_trace(agent: Any) -> dict[str, Any]:
    extra: dict[str, Any] = {}
    if hasattr(agent, "outcomes"):  # orchestrator: per-worker reports and failures
        extra = {
            "workers": {
                n: {"report": o.report.model_dump() if o.report else None, "error": o.error}
                for n, o in agent.outcomes.items()
            }
        }
    return {
        **extra,
        "model": getattr(agent.client, "model", "unknown"),
        "plan_history": [p.model_dump() for p in agent.plan_history],
        "transcript": list(agent.transcript),
        "unavailable_tools": sorted(agent.unavailable),
        "degraded": getattr(agent, "degraded", None),
    }


ADAPTER_NAMES = (
    "react_baseline",
    "llm_react",
    "llm_orchestrator",
    "llm_swarm",
    "llm_swarm_norevise",
    "llm_debate",
    "llm_swarm_debate",
)


def make_adapter(name: str, temperature: float = 0.0, risk_guard: bool = False) -> Callable[[str], DiagnosisResult]:
    if name == "react_baseline":
        return react_baseline
    if name == "llm_react":
        return make_llm_react(temperature, risk_guard)
    if name == "llm_orchestrator":
        return make_llm_orchestrator(temperature, risk_guard=risk_guard)
    if name == "llm_swarm":
        return make_llm_swarm(temperature, risk_guard=risk_guard)
    if name == "llm_swarm_norevise":  # ablation: commander writes narrative/severity/escalation, cannot revise
        return make_llm_swarm(temperature, allow_revision=False, risk_guard=risk_guard)
    if name == "llm_debate":  # Stage 8: orchestrator + debate (compare with llm_orchestrator)
        return make_llm_debate(temperature, risk_guard=risk_guard)
    if name == "llm_swarm_debate":  # Stage 8 inside the swarm: commander reviews the debated diagnosis
        return make_llm_swarm(temperature, risk_guard=risk_guard, debate=True)
    raise ValueError(f"unknown agent {name!r}; choose from {ADAPTER_NAMES}")


def result_path(agent: str, tag: str | None) -> Path:
    if tag is not None and not _TAG.match(tag):
        raise ValueError("--tag may contain only letters, digits, '_', '-' and '.'")
    return RESULTS_DIR / (f"{agent}__{tag}.json" if tag else f"{agent}.json")


def _write_report(path: Path, meta: dict[str, Any], scores: list[IncidentScore], complete: bool) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    report = {
        "meta": {**meta, "complete": complete},
        "summary": summarize(scores),
        "incidents": [asdict(s) for s in scores],
    }
    path.write_text(json.dumps(report, indent=2))


def _log_test_opening(agent: str, tag: str | None, ids: list[str]) -> None:
    OPENINGS_LOG.parent.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).isoformat(timespec="seconds")
    with OPENINGS_LOG.open("a") as fh:
        fh.write(f"{stamp}\tagent={agent}\ttag={tag or '-'}\tn={len(ids)}\n")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Score a diagnoser against the gold set")
    ap.add_argument("--agent", default="react_baseline", choices=ADAPTER_NAMES)
    ap.add_argument("--split", default="all", choices=["all", "dev", "test"])
    ap.add_argument("--ids", default=None, help="comma-separated incident ids (overrides --split)")
    ap.add_argument("--limit", type=int, default=None, help="score only the first N selected incidents")
    ap.add_argument("--tag", default=None, help="label for the run; result goes to <agent>__<tag>.json")
    ap.add_argument("--trace", action="store_true", help="save per-incident traces under eval/traces/")
    ap.add_argument("--temperature", type=float, default=0.0)
    ap.add_argument(
        "--risk-guard",
        action="store_true",
        help="raise (never lower) the risk tier when the recommendation names a restart/rollback/scale/etc. "
        "Post-processing only: re-uses cached LLM responses, so it costs no API calls",
    )
    ap.add_argument("--resume", action="store_true", help="skip incidents already finished in the result file")
    args = ap.parse_args(argv)

    ids: list[str] | None
    if args.ids:
        ids = [i.strip() for i in args.ids.split(",") if i.strip()]
    elif args.split != "all":
        ids = load_split(args.split)
    else:
        ids = None
    opens_test = args.split == "test" and not args.ids
    if opens_test:
        _log_test_opening(args.agent, args.tag, ids or [])
        print("NOTE: TEST SET OPENED (logged in eval/test_openings.log). Do not tune on these results.")

    out = result_path(args.agent, args.tag)
    meta: dict[str, Any] = {
        "agent": args.agent,
        "tag": args.tag,
        "split": "ids" if args.ids else args.split,
        "temperature": args.temperature,
        "risk_guard": args.risk_guard,
        "created_at": datetime.now(UTC).isoformat(timespec="seconds"),
    }
    done: dict[str, IncidentScore] = {}
    if args.resume and out.exists():
        for row in json.loads(out.read_text())["incidents"]:
            if not row["error"]:
                done[row["incident_id"]] = IncidentScore(**row)
        print(f"resuming: {len(done)} incident(s) already finished")

    diagnose = make_adapter(args.agent, args.temperature, args.risk_guard)
    trace_dir = TRACE_DIR / (args.tag or args.agent)
    scores_so_far: list[IncidentScore] = list(done.values())

    def on_result(score: IncidentScore, res: DiagnosisResult) -> None:
        scores_so_far.append(score)
        _write_report(out, meta, scores_so_far, complete=False)  # survives quota cut-offs
        if args.trace and res.trace:
            trace_dir.mkdir(parents=True, exist_ok=True)
            (trace_dir / f"{score.incident_id}.json").write_text(json.dumps(res.trace, indent=2))

    report = evaluate(diagnose, ids=ids, limit=args.limit, on_result=on_result, skip=done)
    final = [IncidentScore(**r) for r in report["incidents"]]
    _write_report(out, meta, final, complete=True)

    for r in report["incidents"]:
        line = f"{r['incident_id']} {r['category']:<22} f1={r['root_cause_f1']:.2f} risk={r['risk_match']}"
        print(line + (f"  CRASHED -> {r['error'][:300]}" if r["error"] else ""))
    print(json.dumps(report["summary"], indent=2))
    if report["summary"]["crashed"]:
        n = report["summary"]["crashed"]
        print(f"\nWARNING: {n} incident(s) crashed - these scores are meaningless until fixed.")
    print(f"saved -> {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
